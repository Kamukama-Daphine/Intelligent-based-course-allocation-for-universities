<div class="nava">
<nav class="navbar navbar-expand-lg navbar-light" style="background-color:#008000;>
  <a class="navbar-brand" href="#">
      <img src="images/logo.png" width="70" height="50" class="d-inline-block align-top" alt=""> &nbsp &nbsp &nbsp &nbsp
  <span>Intelligent Based Course Allocation For Universities</span><br><center><span>&nbsp &nbsp| Department of Computer Science </center></span>
  </a>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav" style="background-color:green;">
            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:white;">
          Account
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="lec.php">Lecturer Login</a>
          <a class="dropdown-item" href="index.php">Admin Login</a>
          
        </div>
      </li>
    </ul>
  </div>
  </div>
</nav>

